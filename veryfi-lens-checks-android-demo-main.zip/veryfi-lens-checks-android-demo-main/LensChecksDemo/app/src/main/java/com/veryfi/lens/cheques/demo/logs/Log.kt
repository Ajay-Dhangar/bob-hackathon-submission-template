package com.veryfi.lens.cheques.demo.logs

class Log {
    var title = ""
    var message = ""
}